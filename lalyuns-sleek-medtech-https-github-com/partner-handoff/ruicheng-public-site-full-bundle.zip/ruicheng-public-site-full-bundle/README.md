# 睿程生醫官網整合包

這份整合包是為 `lalyuns/sleek-medtech` 準備的官網/CMS整合資料，包含程式碼 patch、目前 CMS 內容、產品資料、圖片與 STL 素材。

## 內容

- `ruicheng-public-site-integration.patch`
  - 可套用到 `lalyuns/sleek-medtech` 的程式碼 patch。
  - 包含官網、展示頁、訂購頁、加入我們、CMS、小睿 AI、LineBot 入口、後端 API 與 migration。
- `data/cms-current-content.json`
  - 目前 CMS 實際儲存在本機資料庫的官網內容。
  - 包含後續手動修改過的文字、Hero 圖片 data URL、首頁展示卡片、LineBot 與 AI 設定。
- `data/public-products.json`
  - 目前產品目錄/訂購頁用的產品資料。
- `data/existing-product-requests-export.json`
  - 本機既有產品訂購/需求資料備份。
- `assets/frontend-public/images`
  - 官網使用的圖片素材。
- `assets/frontend-public/models`
  - 官網公開 3D 展示用 STL。
- `import_public_site_data.py`
  - 套用 migration 後，可把 CMS 內容與產品資料匯入 SQLite 開發資料庫。

## 套用方式

在乾淨的 `lalyuns/sleek-medtech` repo 中：

```bash
git apply /path/to/ruicheng-public-site-full-bundle/ruicheng-public-site-integration.patch
```

接著跑 migration：

```bash
cd backend
alembic upgrade head
```

若要把目前手動調整過的 CMS 內容與產品資料也匯入本機 SQLite：

```bash
cd backend
/path/to/ruicheng-public-site-full-bundle/import_public_site_data.py
```

若資料庫檔案不是 `backend/sleek_dev.db`，可以指定路徑：

```bash
/path/to/ruicheng-public-site-full-bundle/import_public_site_data.py /path/to/sleek_dev.db
```

## 注意

- `cms-current-content.json` 內含 Hero 圖片的 base64 data URL，這是為了保留後續手動上傳/調整後的實際顯示內容。
- 圖片與 STL 素材也已放在 `assets` 內，patch 本身也包含前端 public assets。
- `linebot/main.py` 沒有納入本整合包，因為它是夥伴 repo clone 下來後本來就顯示 dirty 的檔案，和官網整合無關。
